from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_migrate import Migrate
from functools import wraps
from markupsafe import escape
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), default="user")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    sites = db.relationship('Site', backref='user', lazy=True, cascade="all, delete-orphan")

class Site(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    url = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(50), default="Bilinmiyor")
    check_interval = db.Column(db.Integer, default=5)  # dakika cinsinden
    last_check = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash("Bu işlem için yetkiniz yok!", "danger")
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/site_management')
@login_required
def site_management():
    sites = Site.query.filter_by(user_id=current_user.id).all()
    return render_template('site_management.html', sites=sites)

@app.route('/user_management')
@login_required
@admin_required
def user_management():
    users = User.query.all()
    return render_template('user_management.html', users=users)

@app.route('/delete_user/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    if user_id == current_user.id:
        flash("Kendi hesabınızı silemezsiniz!", "danger")
        return redirect(url_for('user_management'))
    
    user = db.session.get(User, user_id)
    if user:
        db.session.delete(user)
        db.session.commit()
        flash("Kullanıcı başarıyla silindi.", "success")

    return redirect(url_for('user_management'))

@app.route('/edit_user/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def edit_user(user_id):
    user = db.session.get(User, user_id)
    if not user:
        flash("Kullanıcı bulunamadı!", "danger")
        return redirect(url_for('user_management'))

    username = request.form.get('username')
    role = request.form.get('role')
    password = request.form.get('password')

    if username and username != user.username:
        if User.query.filter_by(username=username).first():
            flash("Bu kullanıcı adı zaten kullanımda!", "danger")
            return redirect(url_for('user_management'))
        user.username = username

    if role:
        user.role = role

    if password:
        user.password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)

    db.session.commit()
    flash("Kullanıcı bilgileri güncellendi.", "success")
    return redirect(url_for('user_management'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = escape(request.form.get('username'))
        password = request.form.get('password')

        if not username or not password:
            flash('Kullanıcı adı ve şifre boş olamaz!', 'danger')
            return redirect(url_for('register'))

        if User.query.filter_by(username=username).first():
            flash('Bu kullanıcı adı zaten alınmış!', 'danger')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash('Kayıt başarılı! Giriş yapabilirsiniz.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = escape(request.form.get('username'))
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            remember = True if request.form.get('remember') else False
            login_user(user, remember=remember)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))

        flash('Geçersiz kullanıcı adı veya şifre!', 'danger')

    return render_template('login.html')

@app.route('/dashboard')
@login_required
def dashboard():
    sites = Site.query.filter_by(user_id=current_user.id).all()
    return render_template('dashboard.html', sites=sites)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Başarıyla çıkış yaptınız.', 'success')
    return redirect(url_for('login'))

@app.route('/add_url', methods=['POST'])
@login_required
def add_url():
    name = request.form.get('name')
    url = request.form.get('url')
    check_interval = request.form.get('check_interval', 5)

    if not name or not url:
        flash('Site adı ve URL boş olamaz!', 'danger')
        return redirect(url_for('site_management'))

    new_site = Site(
        name=name,
        url=url,
        user_id=current_user.id,
        check_interval=check_interval
    )
    db.session.add(new_site)
    db.session.commit()
    flash('Site başarıyla eklendi.', 'success')
    return redirect(url_for('site_management'))

@app.route('/edit_url/<int:id>', methods=['POST'])
@login_required
def edit_url(id):
    site = Site.query.get_or_404(id)
    if site.user_id != current_user.id:
        flash('Bu siteyi düzenleme yetkiniz yok!', 'danger')
        return redirect(url_for('site_management'))

    name = request.form.get('name')
    url = request.form.get('url')
    check_interval = request.form.get('check_interval')

    if name:
        site.name = name
    if url:
        site.url = url
    if check_interval:
        site.check_interval = int(check_interval)

    db.session.commit()
    flash('Site başarıyla güncellendi.', 'success')
    return redirect(url_for('site_management'))

@app.route('/delete_url/<int:id>', methods=['POST'])
@login_required
def delete_url(id):
    site = Site.query.get_or_404(id)
    if site.user_id != current_user.id:
        flash('Bu siteyi silme yetkiniz yok!', 'danger')
        return redirect(url_for('site_management'))

    db.session.delete(site)
    db.session.commit()
    flash('Site başarıyla silindi.', 'success')
    return redirect(url_for('site_management'))

@app.route('/admin')
@login_required
@admin_required
def admin():
    users = User.query.all()
    return render_template('admin.html', users=users)

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
