function checkSite() {
    const url = document.getElementById('url').value;
    const resultElement = document.getElementById('result');

    if (url === "") {
        resultElement.innerText = "Lütfen bir URL girin!";
        return;
    }

    fetch(`/check?url=${url}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'active') {
                resultElement.innerText = "Site Aktif!";
                resultElement.style.color = "green";
            } else {
                resultElement.innerText = "Site Pasif!";
                resultElement.style.color = "red";
            }
        })
        .catch(() => {
            resultElement.innerText = "Siteye Bağlantı Sağlanamadı!";
            resultElement.style.color = "red";
        });
}
