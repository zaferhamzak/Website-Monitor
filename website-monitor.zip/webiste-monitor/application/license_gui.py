import tkinter as tk
from tkinter import ttk, messagebox
from license_manager import LicenseManager
import os
from datetime import datetime
from ttkthemes import ThemedTk

class LicenseManagerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("SiteGuard Lisans Yöneticisi")
        self.root.geometry("900x700")
        
        # Tema ve stil ayarları
        self.root.configure(bg="#f0f0f0")
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 14, "bold"), padding=10)
        style.configure("Header.TLabel", font=("Arial", 12, "bold"), padding=5)
        style.configure("Info.TLabel", font=("Courier", 10), padding=5)
        style.configure("Custom.TButton", font=("Arial", 10), padding=10)
        
        self.license_manager = LicenseManager()
        
        # Ana container
        container = ttk.Frame(root, padding="20")
        container.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Header
        header_frame = ttk.Frame(container)
        header_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 20))
        
        ttk.Label(header_frame, text="SiteGuard Lisans Yönetimi", style="Title.TLabel").pack(side=tk.LEFT)
        
        # Donanım ID bölümü
        hardware_frame = ttk.LabelFrame(container, text="Sistem Bilgileri", padding="10")
        hardware_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 20))
        
        hardware_id = self.license_manager.get_hardware_id()
        ttk.Label(hardware_frame, text="Donanım ID:", style="Header.TLabel").grid(row=0, column=0, sticky=tk.W)
        ttk.Label(hardware_frame, text=hardware_id, style="Info.TLabel").grid(row=0, column=1, sticky=tk.W, padx=10)
        
        # Lisans oluşturma formu
        form_frame = ttk.LabelFrame(container, text="Yeni Lisans Oluştur", padding="10")
        form_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 20))
        
        # Form elemanları
        # Müşteri adı
        ttk.Label(form_frame, text="Müşteri Adı:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.customer_name = ttk.Entry(form_frame, width=40)
        self.customer_name.grid(row=0, column=1, columnspan=2, sticky=tk.W, pady=5)
        
        # Süre
        ttk.Label(form_frame, text="Süre (Gün):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.expiry_days = ttk.Spinbox(form_frame, from_=1, to=3650, width=10)
        self.expiry_days.set("365")
        self.expiry_days.grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Site limiti
        ttk.Label(form_frame, text="Maksimum Site:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.max_sites = ttk.Spinbox(form_frame, from_=1, to=1000, width=10)
        self.max_sites.set("10")
        self.max_sites.grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Kullanıcı limiti
        ttk.Label(form_frame, text="Maksimum Kullanıcı:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.max_users = ttk.Spinbox(form_frame, from_=1, to=1000, width=10)
        self.max_users.set("5")
        self.max_users.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Özellikler
        ttk.Label(form_frame, text="Özellikler:").grid(row=4, column=0, sticky=tk.W, pady=5)
        features_frame = ttk.Frame(form_frame)
        features_frame.grid(row=4, column=1, columnspan=2, sticky=tk.W, pady=5)
        
        self.feature_vars = {}
        default_features = ["basic", "site_management", "user_management"]
        for i, feature in enumerate(default_features):
            var = tk.BooleanVar(value=True)
            self.feature_vars[feature] = var
            ttk.Checkbutton(features_frame, text=feature.replace("_", " ").title(), 
                          variable=var).grid(row=0, column=i, padx=10)
        
        # Buton çubuğu
        button_frame = ttk.Frame(container)
        button_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=20)
        
        ttk.Button(button_frame, text="Lisans Oluştur", style="Custom.TButton",
                  command=self.create_license).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Lisans Kontrol", style="Custom.TButton",
                  command=self.check_license).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Çıkış", style="Custom.TButton",
                  command=root.quit).pack(side=tk.RIGHT, padx=5)
        
        # Lisans bilgi alanı
        info_frame = ttk.LabelFrame(container, text="Mevcut Lisans Bilgileri", padding="10")
        info_frame.grid(row=4, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.license_info_text = tk.Text(info_frame, height=12, width=70, font=("Courier", 10))
        self.license_info_text.pack(expand=True, fill=tk.BOTH)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(info_frame, orient=tk.VERTICAL, command=self.license_info_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.license_info_text.configure(yscrollcommand=scrollbar.set)
        
        # Grid yapılandırması
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)
        
        # İlk açılışta lisans kontrolü yap
        self.check_license()
    
    def create_license(self):
        try:
            # Form verilerini al
            customer = self.customer_name.get().strip()
            days = int(self.expiry_days.get())
            sites = int(self.max_sites.get())
            users = int(self.max_users.get())
            
            # Seçili özellikleri al
            features = [feature for feature, var in self.feature_vars.items() if var.get()]
            
            if not customer:
                messagebox.showerror("Hata", "Müşteri adı boş olamaz!")
                return
                
            # Lisans oluştur
            license_data = self.license_manager.create_license(
                customer_name=customer,
                expiry_days=days,
                max_sites=sites,
                max_users=users,
                features=features
            )
            
            if license_data:
                messagebox.showinfo("Başarılı", "Lisans başarıyla oluşturuldu!")
                self.check_license()  # Lisans bilgilerini güncelle
            else:
                messagebox.showerror("Hata", "Lisans oluşturulamadı!")
                
        except ValueError:
            messagebox.showerror("Hata", "Lütfen sayısal değerleri doğru giriniz!")
        except Exception as e:
            messagebox.showerror("Hata", f"Beklenmeyen bir hata oluştu: {str(e)}")
    
    def check_license(self):
        self.license_info_text.delete(1.0, tk.END)
        
        if not os.path.exists(self.license_manager.license_file):
            self.license_info_text.insert(tk.END, "Lisans dosyası bulunamadı!\n")
            return
            
        is_valid, license_info = self.license_manager.verify_license()
        
        if not is_valid:
            self.license_info_text.insert(tk.END, f"Lisans geçersiz: {license_info}\n")
            return
            
        if isinstance(license_info, dict):
            self.license_info_text.insert(tk.END, "=== Mevcut Lisans Bilgileri ===\n\n")
            self.license_info_text.insert(tk.END, f"Müşteri: {license_info['customer_name']}\n")
            self.license_info_text.insert(tk.END, f"Lisans Anahtarı: {license_info['license_key']}\n")
            self.license_info_text.insert(tk.END, f"Başlangıç: {license_info['issue_date']}\n")
            self.license_info_text.insert(tk.END, f"Bitiş: {license_info['expiry_date']}\n")
            self.license_info_text.insert(tk.END, f"Maksimum Site: {license_info['max_sites']}\n")
            self.license_info_text.insert(tk.END, f"Maksimum Kullanıcı: {license_info['max_users']}\n")
            self.license_info_text.insert(tk.END, f"Özellikler: {', '.join(license_info['features'])}\n")
            self.license_info_text.insert(tk.END, f"Donanım ID: {license_info['hardware_id']}\n")
            
            # Kalan süreyi hesapla
            expiry = datetime.fromisoformat(license_info['expiry_date'])
            remaining = expiry - datetime.utcnow()
            self.license_info_text.insert(tk.END, f"\nKalan Süre: {remaining.days} gün\n")
        else:
            self.license_info_text.insert(tk.END, "Lisans bilgisi okunamadı!\n")

def main():
    root = ThemedTk(theme="arc")  # Modern bir tema kullan
    app = LicenseManagerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()