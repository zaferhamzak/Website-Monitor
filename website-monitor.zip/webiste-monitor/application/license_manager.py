import hashlib
import json
from datetime import datetime, timedelta
import os
import uuid
import requests
import logging
from cryptography.fernet import Fernet
from flask import abort, current_app

class LicenseManager:
    def __init__(self):
        self.license_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "instance/license.key")
        self.hardware_id = self.get_hardware_id()
        self.key = self._load_or_create_key()
        self.cipher_suite = Fernet(self.key)
        
        # License dosyası dizinini oluştur
        os.makedirs(os.path.dirname(self.license_file), exist_ok=True)
        if os.path.exists(self.license_file):
            try:
                os.chmod(self.license_file, 0o600)
            except:
                pass

    def _load_or_create_key(self):
        key_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "instance/crypto.key")
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(key_file), exist_ok=True)
            
            if os.path.exists(key_file):
                try:
                    with open(key_file, 'rb') as f:
                        return f.read()
                except PermissionError:
                    logging.error(f"Crypto key okuma izni yok: {key_file}")
                    return Fernet.generate_key()
            else:
                key = Fernet.generate_key()
                try:
                    with open(key_file, 'wb') as f:
                        f.write(key)
                    try:
                        os.chmod(key_file, 0o600)
                    except:
                        pass
                except PermissionError:
                    logging.error(f"Crypto key yazma izni yok: {key_file}")
                return key
        except Exception as e:
            logging.error(f"Anahtar yükleme hatası: {str(e)}")
            return Fernet.generate_key()
        
    def get_hardware_id(self):
        """Sistemin benzersiz donanım kimliğini oluşturur."""
        try:
            # MAC adresi
            mac = uuid.getnode()
            # İşletim sistemi bilgileri
            os_info = os.uname() if hasattr(os, 'uname') else os.name
            # Hostname
            hostname = os.uname().nodename if hasattr(os, 'uname') else os.environ.get('COMPUTERNAME', '')
            
            # Bu bilgileri birleştir ve hash'le
            unique_id = f"{mac}-{os_info}-{hostname}"
            return hashlib.sha256(unique_id.encode()).hexdigest()
        except Exception as e:
            logging.error(f"Hardware ID oluşturma hatası: {str(e)}")
            return hashlib.sha256(str(uuid.getnode()).encode()).hexdigest()

    def create_license(self, customer_name, hardware_id, expiry_days=365, max_sites=10, max_users=5, features=None):
        """Yönetici tarafından yeni lisans oluşturur."""
        try:
            if features is None:
                features = ["basic", "site_management", "user_management"]

            issue_date = datetime.utcnow()
            expiry_date = issue_date + timedelta(days=expiry_days)
            
            license_data = {
                "customer_name": customer_name,
                "hardware_id": hardware_id,  # Müşterinin donanım ID'si
                "license_key": str(uuid.uuid4()),
                "issue_date": issue_date.isoformat(),
                "expiry_date": expiry_date.isoformat(),
                "max_sites": max_sites,
                "max_users": max_users,
                "features": features
            }
            
            # Lisans verisini şifrele
            encrypted_data = self.cipher_suite.encrypt(json.dumps(license_data).encode())
            return encrypted_data, license_data
            
        except Exception as e:
            logging.error(f"Lisans oluşturma hatası: {str(e)}")
            return None, None

    def activate_license(self, license_data):
        """Müşteri tarafında lisansı aktive eder."""
        try:
            # Lisans verisini deşifre et
            decrypted_data = self.cipher_suite.decrypt(license_data)
            license_info = json.loads(decrypted_data.decode())
            
            # Hardware ID kontrolü
            if license_info["hardware_id"] != self.hardware_id:
                return False, "Lisans bu cihaz için geçerli değil"
                
            # Lisans dosyasına yaz
            with open(self.license_file, 'wb') as f:
                f.write(license_data)
            
            return True, "Lisans başarıyla aktive edildi"
            
        except Exception as e:
            logging.error(f"Lisans aktivasyon hatası: {str(e)}")
            return False, str(e)

    def verify_license(self):
        """Mevcut lisansı doğrular."""
        try:
            if not os.path.exists(self.license_file):
                return False, "Lisans dosyası bulunamadı"
                
            with open(self.license_file, 'rb') as f:
                encrypted_data = f.read()
                
            # Lisans verisini deşifre et
            decrypted_data = self.cipher_suite.decrypt(encrypted_data)
            license_data = json.loads(decrypted_data.decode())
            
            # Hardware ID kontrolü
            if license_data["hardware_id"] != self.hardware_id:
                return False, "Geçersiz donanım kimliği"
                
            # Süre kontrolü
            expiry_date = datetime.fromisoformat(license_data["expiry_date"])
            if datetime.utcnow() > expiry_date:
                return False, "Lisans süresi dolmuş"
                
            return True, license_data
            
        except Exception as e:
            logging.error(f"Lisans doğrulama hatası: {str(e)}")
            return False, str(e)

    def check_feature_access(self, feature_name):
        """Belirli bir özelliğe erişim iznini kontrol eder."""
        try:
            is_valid, license_data = self.verify_license()
            if not is_valid or not isinstance(license_data, dict):
                return False
            
            return feature_name in license_data.get("features", [])
        except Exception as e:
            logging.error(f"Özellik kontrolü hatası: {str(e)}")
            return False

    def check_limits(self, site_count=None, user_count=None):
        """Kullanım limitlerini kontrol eder."""
        try:
            is_valid, license_data = self.verify_license()
            if not is_valid or not isinstance(license_data, dict):
                return False
            
            if site_count is not None and site_count > license_data.get("max_sites", 0):
                return False
                
            if user_count is not None and user_count > license_data.get("max_users", 0):
                return False
                
            return True
        except Exception as e:
            logging.error(f"Limit kontrolü hatası: {str(e)}")
            return False
            
    def get_license_info(self):
        """Mevcut lisans bilgilerini döndürür."""
        is_valid, license_data = self.verify_license()
        if not is_valid or not isinstance(license_data, dict):
            return None
        return license_data

def license_required(feature=None):
    """Lisans gerektiren route'lar için dekoratör"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            license_manager = LicenseManager()
            is_valid, _ = license_manager.verify_license()
            
            if not is_valid:
                abort(403, description="Geçerli lisans bulunamadı")
            
            if feature and not license_manager.check_feature_access(feature):
                abort(403, description="Bu özellik için lisansınız bulunmuyor")
                
            return f(*args, **kwargs)
        return decorated_function
    return decorator