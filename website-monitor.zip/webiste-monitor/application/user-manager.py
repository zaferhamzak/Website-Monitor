import sys
from app import db, User
from werkzeug.security import generate_password_hash

def list_users():
    users = User.query.all()
    if not users:
        print("Hiç kullanıcı yok!")
    else:
        for user in users:
            print(f"ID: {user.id}, Kullanıcı Adı: {user.username}")

def validate_username(username):
    if not 3 <= len(username) <= 32:
        return False, "Kullanıcı adı 3-32 karakter arasında olmalıdır"
    if not username.isalnum():
        return False, "Kullanıcı adı sadece harf ve rakam içerebilir"
    return True, ""

def add_user(username, password):
    is_valid, message = validate_username(username)
    if not is_valid:
        print(f"Hata: {message}")
        return
        
    if len(password) < 8:
        print("Şifre en az 8 karakter olmalıdır!")
        return
        
    if User.query.filter_by(username=username).first():
        print("Bu kullanıcı adı zaten mevcut!")
        return
        
    try:
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        print(f"Kullanıcı '{username}' eklendi!")
    except Exception as e:
        db.session.rollback()
        print(f"Kullanıcı eklenirken hata oluştu: {str(e)}")

def delete_user(user_id):
    user = User.query.get(user_id)
    if not user:
        print("Böyle bir kullanıcı bulunamadı!")
        return
    db.session.delete(user)
    db.session.commit()
    print(f"Kullanıcı '{user.username}' silindi!")

def reset_password(user_id, new_password):
    user = User.query.get(user_id)
    if not user:
        print("Böyle bir kullanıcı bulunamadı!")
        return
    user.password = generate_password_hash(new_password, method='pbkdf2:sha256', salt_length=16)
    db.session.commit()
    print(f"Kullanıcının ({user.username}) şifresi güncellendi!")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Kullanım: python user_manager.py <komut> [opsiyonlar]")
        print("Komutlar:")
        print("  list                      -> Kullanıcıları listele")
        print("  add <username> <password> -> Yeni kullanıcı ekle")
        print("  delete <id>               -> Kullanıcı sil")
        print("  reset <id> <new_password> -> Şifre sıfırla")
        sys.exit(1)

    command = sys.argv[1]

    if command == "list":
        list_users()
    elif command == "add" and len(sys.argv) == 4:
        add_user(sys.argv[2], sys.argv[3])
    elif command == "delete" and len(sys.argv) == 3:
        delete_user(int(sys.argv[2]))
    elif command == "reset" and len(sys.argv) == 4:
        reset_password(int(sys.argv[2]), sys.argv[3])
    else:
        print("Hatalı kullanım! Komutları doğru girin.")
