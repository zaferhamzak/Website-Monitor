#!/usr/bin/env python3
import sys
import argparse
from license_manager import LicenseManager

def create_parser():
    parser = argparse.ArgumentParser(description='SiteGuard Lisans Yönetim Aracı')
    subparsers = parser.add_subparsers(dest='command', help='Komutlar')

    # Lisans oluşturma komutu
    create_parser = subparsers.add_parser('create', help='Yeni lisans oluştur')
    create_parser.add_argument('--customer', required=True, help='Müşteri adı')
    create_parser.add_argument('--hardware-id', required=True, help='Müşteri donanım ID\'si')
    create_parser.add_argument('--days', type=int, default=365, help='Lisans süresi (gün)')
    create_parser.add_argument('--max-sites', type=int, default=10, help='Maksimum site sayısı')
    create_parser.add_argument('--max-users', type=int, default=5, help='Maksimum kullanıcı sayısı')
    create_parser.add_argument('--features', nargs='+', default=['basic', 'site_management', 'user_management'],
                             help='Lisans özellikleri')

    # Lisans bilgisi görüntüleme komutu
    info_parser = subparsers.add_parser('info', help='Lisans bilgilerini göster')

    # Lisans doğrulama komutu
    verify_parser = subparsers.add_parser('verify', help='Lisansı doğrula')

    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    license_manager = LicenseManager()

    if args.command == 'create':
        encrypted_data, license_data = license_manager.create_license(
            customer_name=args.customer,
            hardware_id=args.hardware_id,
            expiry_days=args.days,
            max_sites=args.max_sites,
            max_users=args.max_users,
            features=args.features
        )
        if encrypted_data and license_data:
            print("\nLisans başarıyla oluşturuldu!")
            print("-" * 40)
            print(f"Müşteri: {license_data['customer_name']}")
            print(f"Lisans Anahtarı: {license_data['license_key']}")
            print(f"Başlangıç: {license_data['issue_date']}")
            print(f"Bitiş: {license_data['expiry_date']}")
            print(f"Maksimum Site: {license_data['max_sites']}")
            print(f"Maksimum Kullanıcı: {license_data['max_users']}")
            print(f"Özellikler: {', '.join(license_data['features'])}")
            print(f"Donanım ID: {license_data['hardware_id']}")
            print("\nŞifrelenmiş Lisans Anahtarı:")
            print(encrypted_data.decode())
        else:
            print("Lisans oluşturma hatası!")

    elif args.command == 'info':
        license_data = license_manager.get_license_info()
        if license_data:
            print("\nMevcut Lisans Bilgileri:")
            print("-" * 40)
            print(f"Müşteri: {license_data['customer_name']}")
            print(f"Lisans Anahtarı: {license_data['license_key']}")
            print(f"Başlangıç: {license_data['issue_date']}")
            print(f"Bitiş: {license_data['expiry_date']}")
            print(f"Maksimum Site: {license_data['max_sites']}")
            print(f"Maksimum Kullanıcı: {license_data['max_users']}")
            print(f"Özellikler: {', '.join(license_data['features'])}")
            print(f"Donanım ID: {license_data['hardware_id']}")
        else:
            print("Lisans bulunamadı!")

    elif args.command == 'verify':
        is_valid, message = license_manager.verify_license()
        if is_valid:
            print("Lisans geçerli!")
        else:
            print(f"Lisans geçersiz: {message}")

if __name__ == "__main__":
    main()