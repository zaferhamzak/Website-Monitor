from flask import Flask, render_template, redirect, url_for, request, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_migrate import Migrate
from flask_wtf.csrf import CSRFProtect
from functools import wraps
from markupsafe import escape
from datetime import datetime, timezone, timedelta
import requests
from threading import Thread
import time
from license_manager import LicenseManager, license_required
from decorators import admin_required
import re

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['WTF_CSRF_TIME_LIMIT'] = 3600  # 1 hour CSRF token expiry

db = SQLAlchemy(app)
migrate = Migrate(app, db)
csrf = CSRFProtect(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Lisans yöneticisini başlat
license_manager = LicenseManager()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)  # Added email field
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), default="user")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    sites = db.relationship('Site', backref='user', lazy=True, cascade="all, delete-orphan")

class Site(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    url = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(50), default="Bilinmiyor")
    check_interval = db.Column(db.Integer, default=5)
    last_check = db.Column(db.DateTime)
    response_time = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response

def check_site_status(url):
    try:
        start_time = time.time()
        response = requests.get(url, timeout=10, verify=False, 
                              headers={'User-Agent': 'SiteGuard Monitor/1.0'})
        response_time = (time.time() - start_time) * 1000

        if response.status_code == 200:
            return ("Aktif", response_time) if response_time < 500 else ("Uyarı", response_time)
        return "Pasif", response_time
    except requests.RequestException as e:
        app.logger.error(f"Site kontrol hatası ({url}): {str(e)}")
        return "Pasif", 0
    except Exception as e:
        app.logger.error(f"Beklenmeyen hata ({url}): {str(e)}")
        return "Hata", 0

def monitor_sites():
    with app.app_context():
        while True:
            try:
                is_valid, _ = license_manager.verify_license()
                if not is_valid:
                    time.sleep(60)
                    continue

                sites = Site.query.all()
                for site in sites:
                    try:
                        if not site.last_check or \
                           (datetime.utcnow() - site.last_check).total_seconds() >= site.check_interval * 60:
                            status, response_time = check_site_status(site.url)
                            site.status = status
                            site.response_time = response_time
                            site.last_check = datetime.now(timezone.utc)
                            db.session.commit()
                    except Exception as e:
                        app.logger.error(f"Site izleme hatası ({site.url}): {str(e)}")
                        db.session.rollback()
            except Exception as e:
                app.logger.error(f"İzleme thread hatası: {str(e)}")
            finally:
                time.sleep(60)

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/site_management')
@login_required
def site_management():
    if not license_manager.check_feature_access('site_management'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('dashboard'))
    sites = Site.query.filter_by(user_id=current_user.id).all()
    if not license_manager.check_limits(site_count=len(sites)):
        flash("Maksimum site limitine ulaştınız!", "danger")
        return redirect(url_for('dashboard'))
    return render_template('site_management.html', sites=sites)

@app.route('/user_management')
@login_required
@admin_required
def user_management():
    if not license_manager.check_feature_access('user_management'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('dashboard'))
        
    users = User.query.all()
    if not license_manager.check_limits(user_count=len(users)):
        flash("Maksimum kullanıcı limitine ulaştınız!", "danger")
        return redirect(url_for('dashboard'))
    return render_template('user_management.html', users=users)

@app.route('/delete_user/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    if not license_manager.check_feature_access('user_management'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('dashboard'))
    
    if user_id == current_user.id:
        flash("Kendi hesabınızı silemezsiniz!", "danger")
        return redirect(url_for('user_management'))
    
    user = db.session.get(User, user_id)
    if user:
        db.session.delete(user)
        db.session.commit()
        flash("Kullanıcı başarıyla silindi.", "success")

    return redirect(url_for('user_management'))

def validate_password(password):
    if len(password) < 8:
        return False, "Şifre en az 8 karakter olmalıdır"
    if not re.search("[A-Z]", password):
        return False, "Şifre en az bir büyük harf içermelidir"
    if not re.search("[a-z]", password):
        return False, "Şifre en az bir küçük harf içermelidir"
    if not re.search("[0-9]", password):
        return False, "Şifre en az bir rakam içermelidir"
    return True, None

@app.route('/edit_user/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def edit_user(user_id):
    if not license_manager.check_feature_access('user_management'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('dashboard'))
    
    try:
        user = db.session.get(User, user_id)
        if not user:
            flash("Kullanıcı bulunamadı!", "danger")
            return redirect(url_for('user_management'))

        username = escape(request.form.get('username'))
        role = escape(request.form.get('role'))
        password = request.form.get('password')

        if username and username != user.username:
            if not username.isalnum():
                flash("Kullanıcı adı sadece harf ve rakam içerebilir!", "danger")
                return redirect(url_for('user_management'))
            if User.query.filter_by(username=username).first():
                flash("Bu kullanıcı adı zaten kullanımda!", "danger")
                return redirect(url_for('user_management'))
            user.username = username

        if role in ['admin', 'user']:
            user.role = role

        if password:
            is_valid, message = validate_password(password)
            if not is_valid:
                flash(message, "danger")
                return redirect(url_for('user_management'))
            user.password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)

        db.session.commit()
        flash("Kullanıcı bilgileri güncellendi.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Hata oluştu: {str(e)}", "danger")
        
    return redirect(url_for('user_management'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    # Lisans kontrolü
    is_valid, _ = license_manager.verify_license()
    if not is_valid:
        flash("Geçerli bir lisans bulunamadı!", "danger")
        return redirect(url_for('login'))

    if request.method == 'POST':
        try:
            username = escape(request.form.get('username'))
            password = request.form.get('password')
            email = escape(request.form.get('email'))

            if not username or not password or not email:
                flash('Tüm alanları doldurun!', 'danger')
                return redirect(url_for('register'))

            if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                flash('Geçerli bir email adresi girin!', 'danger')
                return redirect(url_for('register'))

            if not username.isalnum():
                flash("Kullanıcı adı sadece harf ve rakam içerebilir!", "danger")
                return redirect(url_for('register'))

            is_valid, message = validate_password(password)
            if not is_valid:
                flash(message, "danger")
                return redirect(url_for('register'))

            if User.query.filter_by(username=username).first():
                flash('Bu kullanıcı adı zaten alınmış!', 'danger')
                return redirect(url_for('register'))

            # Kullanıcı sayısı limitini kontrol et
            users = User.query.all()
            if not license_manager.check_limits(user_count=len(users) + 1):
                flash("Maksimum kullanıcı limitine ulaşıldı!", "danger")
                return redirect(url_for('login'))

            hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
            new_user = User(username=username, email=email, password=hashed_password, role='user')
            db.session.add(new_user)
            db.session.commit()
            flash('Başarıyla kayıt oldunuz!', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f"Kayıt sırasında hata oluştu: {str(e)}", "danger")
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Lisans kontrolü
    is_valid, license_info = license_manager.verify_license()
    if not is_valid:
        flash("Geçerli bir lisans bulunamadı!", "danger")
        return render_template('license_error.html')

    if request.method == 'POST':
        username = escape(request.form.get('username'))
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            remember = True if request.form.get('remember') else False
            login_user(user, remember=remember)
            user.last_login = datetime.now(timezone.utc)
            db.session.commit()
            
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))

        flash('Geçersiz kullanıcı adı veya şifre!', 'danger')

    return render_template('login.html')

@app.route('/dashboard')
@login_required
def dashboard():
    if not license_manager.check_feature_access('basic'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('login'))
    sites = Site.query.filter_by(user_id=current_user.id).all()
    return render_template('dashboard.html', sites=sites)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Başarıyla çıkış yaptınız.', 'success')
    return redirect(url_for('login'))

@app.route('/add_url', methods=['POST'])
@login_required
def add_url():
    if not license_manager.check_feature_access('site_management'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('dashboard'))
        
    try:
        # Form verilerini al ve doğrula
        name = request.form.get('name', '').strip()
        url = request.form.get('url', '').strip()
        check_interval = request.form.get('check_interval', '5')

        # Validasyon kontrolleri
        if not name or not url:
            flash('Site adı ve URL alanları zorunludur!', 'danger')
            return redirect(url_for('dashboard'))

        # Site sayısı limitini kontrol et
        sites = Site.query.filter_by(user_id=current_user.id).all()
        if not license_manager.check_limits(site_count=len(sites) + 1):
            flash("Maksimum site limitine ulaşıldı!", "danger")
            return redirect(url_for('dashboard'))

        # URL formatını düzelt
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        # Yeni site oluştur
        new_site = Site(
            name=name,
            url=url,
            user_id=current_user.id,
            check_interval=int(check_interval),
            created_at=datetime.now(timezone.utc),
            last_check=datetime.now(timezone.utc)
        )
        
        # Site durumunu kontrol et
        try:
            status, response_time = check_site_status(url)
            new_site.status = status
            new_site.response_time = response_time
        except Exception as e:
            app.logger.error(f"Site kontrol hatası ({url}): {str(e)}")
            new_site.status = "Hata"
            new_site.response_time = 0

        # Veritabanına kaydet
        db.session.add(new_site)
        db.session.commit()

        flash('Site başarıyla eklendi!', 'success')
        return redirect(url_for('dashboard'))

    except Exception as e:
        app.logger.error(f"Site ekleme hatası: {str(e)}")
        db.session.rollback()
        flash(f'Site eklenirken bir hata oluştu!', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/edit_url/<int:id>', methods=['POST'])
@login_required
def edit_url(id):
    if not license_manager.check_feature_access('site_management'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('dashboard'))

    site = Site.query.get_or_404(id)
    if site.user_id != current_user.id:
        flash('Bu siteyi düzenleme yetkiniz yok!', 'danger')
        return redirect(url_for('site_management'))

    name = request.form.get('name')
    url = request.form.get('url')
    check_interval = request.form.get('check_interval')

    if name:
        site.name = name
    if url:
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        site.url = url
        status, response_time = check_site_status(url)
        site.status = status
        site.response_time = response_time
        site.last_check = datetime.now(timezone.utc)
    if check_interval:
        site.check_interval = int(check_interval)

    db.session.commit()
    flash('Site başarıyla güncellendi.', 'success')
    return redirect(url_for('site_management'))

@app.route('/delete_url/<int:id>', methods=['POST'])
@login_required
def delete_url(id):
    if not license_manager.check_feature_access('site_management'):
        flash("Bu özellik için lisansınız bulunmuyor!", "danger")
        return redirect(url_for('dashboard'))

    site = Site.query.get_or_404(id)
    if site.user_id != current_user.id:
        flash('Bu siteyi silme yetkiniz yok!', 'danger')
        return redirect(url_for('site_management'))

    db.session.delete(site)
    db.session.commit()
    flash('Site başarıyla silindi.', 'success')
    return redirect(url_for('site_management'))

@app.route('/license')
@login_required
@admin_required
def license_info():
    license_data = license_manager.get_license_info()
    if not license_data:
        flash("Lisans bilgisi bulunamadı!", "danger")
        return redirect(url_for('dashboard'))
    
    # Kullanıcı ve site sayılarını al
    users = User.query.all()
    sites = Site.query.all()
    
    # Yüzdeleri hesapla
    user_percent = min(round((len(users) / license_data['max_users']) * 100), 100)
    site_percent = min(round((len(sites) / license_data['max_sites']) * 100), 100)
    
    # Şu anki tarihi al
    now = datetime.now().strftime('%Y-%m-%d')
    
    return render_template('license.html',
                         license=license_data,
                         users=users,
                         sites=sites,
                         user_percent=user_percent,
                         site_percent=site_percent,
                         now=now)

@app.route('/activate', methods=['GET', 'POST'])
def activate_license():
    license_manager = LicenseManager()
    hardware_id = license_manager.get_hardware_id()
    
    if request.method == 'POST':
        try:
            license_key = request.form.get('license_key', '').strip()
            if not license_key:
                flash('Lütfen lisans anahtarını girin!', 'danger')
                return redirect(url_for('activate_license'))
            
            # Lisansı aktive et
            success, message = license_manager.activate_license(license_key.encode())
            
            if success:
                flash('Lisans başarıyla aktive edildi!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash(f'Lisans aktivasyonu başarısız: {message}', 'danger')
                
        except Exception as e:
            flash(f'Hata oluştu: {str(e)}', 'danger')
        
        return redirect(url_for('activate_license'))
        
    return render_template('activate_license.html', hardware_id=hardware_id)

if __name__ == "__main__":
    # Site izleme thread'ini başlat
    monitor_thread = Thread(target=monitor_sites, daemon=True)
    monitor_thread.start()
    
    with app.app_context():
        db.create_all()

    ssl_context = (
        'instance/cert.pem',  # SSL sertifikası
        'instance/key.pem'    # Private key
    )
    
    app.run(
        host='0.0.0.0',      # Tüm IP'lerden erişime izin ver
        port=443,            # HTTPS portu
        ssl_context=ssl_context,
        debug=True
    )
